<template>
 
</template>

<script>
    export default {
        created(){
          localStorage.removeItem('token')
          localStorage.removeItem('user')
          Toast.fire({
  icon: 'success',
  title: 'You are logout successfully'
})
                    this.$router.push({name:'/'})
        },
     
    }
</script>
<style scoped>

</style>
